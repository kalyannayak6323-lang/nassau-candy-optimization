# Nassau Candy Optimization Recommendation System

This project compares current factory assignments with a modeled distance-based alternative assignment and estimates transportation costs and potential savings.

## Reported dashboard results
- Current transportation cost: **$20.41 million**
- Modeled optimized cost: **$8.31 million**
- Potential savings: **$12.10 million**
- Potential savings percentage: **59.28%**

These are reported estimates under project assumptions, not guaranteed realized savings. Validate factory capacity, inventory, product eligibility, service levels, routes, and actual freight rates before operational use.

## Repository contents
- `src/audit_analysis.py` — audits an Excel workbook's sheets, columns, missing values, duplicates, and numeric summaries.
- `requirements.txt` — Python dependencies.
- `data/README.md` — data access and privacy instructions.
- `outputs/README.md` — output publishing guidance.

## Data access
The raw transaction dataset and derived workbook are not included in this source package. Add only files you are permitted to share. If data is restricted, keep it out of GitHub and document the approved access process. The earlier workflow reported 10,194 transaction rows, 5,044 distance rows, 10,170 matched transactions, and 24 transactions without distance data; re-run against the actual workbook to verify.

## Setup (Python 3.10+)
Windows:
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```
macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Run
List worksheets:
```bash
python src/audit_analysis.py "C:/path/to/final_factory_analysis.xlsx" --list-sheets
```
Audit a selected worksheet:
```bash
python src/audit_analysis.py "C:/path/to/final_factory_analysis.xlsx" --sheet "Sheet1"
```
Replace the path and worksheet name with your actual workbook details. The script audits the workbook; it does not claim to reproduce optimization results from unknown column definitions.

## Methodology
1. Inspect and clean transaction/location data.
2. Geocode customer locations when coordinates are absent, respecting provider terms and rate limits.
3. Match transactions with available distance records and flag unmatched rows.
4. Compare current assignments with modeled alternatives.
5. Estimate transportation cost using the documented assumption (the project used $1/km).
6. Calculate savings as current cost minus modeled optimized cost.
7. Validate results against the Excel analysis and Power BI report.

## Limitations
- Nearest-factory assignment is not a complete operational optimization unless capacity, inventory, product eligibility, service levels, and other constraints are represented.
- $1/km is a modeling assumption; use validated carrier rates when available.
- Geocoding can be approximate or fail; review unmatched and ambiguous locations.
- Reproduce and validate all reported metrics from the authorized input workbook before treating them as verified.

## Links
- Power BI report: https://app.powerbi.com/links/BoZr2PYpUU?ctid=99ad5b45-6c02-49e3-af2b-831863f2e0dc&pbi_source=linkShare
- GitHub repository: https://github.com/kalyannayak6323-lang/nassau-candy-optimization
- GitHub Pages (if enabled): https://kalyannayak6323-lang.github.io/nassau-candy-optimization/

Update this README after checking actual repository contents and verifying exact input filenames and results.
