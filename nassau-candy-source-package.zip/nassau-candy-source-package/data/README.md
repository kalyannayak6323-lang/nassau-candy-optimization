# Data access

Raw transactions and derived workbooks are not included in this package.

Before publishing data:
1. Confirm permission to share it.
2. Remove confidential or licensed information as required.
3. If data cannot be shared, document the approved access process and consider a synthetic sample.
4. Record the actual workbook filename, worksheet names, and column definitions here once verified.
